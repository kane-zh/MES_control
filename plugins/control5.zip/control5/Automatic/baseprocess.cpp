#include "baseprocess.h"

BaseProcess::BaseProcess(QObject *parent) : QThread(parent)
{

}

