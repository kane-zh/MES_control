#ifndef RUNTHREAD03_H
#define RUNTHREAD03_H
#include "baseprocess.h"
class RunThread03: public BaseProcess
{
    Q_OBJECT
public:
    explicit RunThread03(QObject *parent = nullptr);
    ~RunThread03();
    void run();
    enum  variable
    {
        currentState,    //当前模块状态
        int0_step,       //初始化0状态步
        int1_step,       //初始化1状态步
        run0_step,       //运行0状态步
        run1_step,       //运行1状态步
    };
     Q_ENUM(variable)
signals:
    void sendMessage(QString);
    void SendMsgToPluginInterface(QString request);
public slots:
    void startInit();
    void startRun();
    void startReset();
    void startAlarm();
    void startPause();
    void startStop();
private:
    void initAndReset();
    void startAndRun();
    void monitor();
    void init_0();
    void init_1();
    void run_0();
    void run_1();
    bool setValue(QString key,QString value);
    QString getValue(QString key);
    void saveConfig();                           //保存配置信息
    void loadConfig();                           //加载配置信息
    bool runFlag=true;
    QHash<QString,QString> m_value;
};

#endif // RUNTHREAD03_H
