﻿#include "runThread06.h"

RunThread06::RunThread06(QObject *parent):BaseProcess(parent)
{

}
RunThread06::~RunThread06()
{
  runFlag=false;
  requestInterruption();
  quit();
  wait();
}
void RunThread06::run()
{
    while(runFlag)
    {
    /*依次调用各部分功能程序，执行哪一步由各功能程序自行判断，但要求各功能程序必须只执行一步并立即
    返回。不允许功能程序卡死*/
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if(currentState==state::IsRuning||currentState==state::IsPause){
      monitor();
    }
    if(currentState==state::IsInitializing){
      initAndReset();
    }
    if(currentState==state::IsRuning){
      startAndRun();
    }
      msleep(500);
    }
}
//初始化启动
void RunThread06::startInit()
{
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if ((currentState == state::Unknown)||
        (currentState == state::IsPause)||
        (currentState == state::IsAlarm))
    {
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::int0_step),"1");
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::int1_step),"1");
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::run0_step),"1");
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::run1_step),"1");
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState),
                 QMetaEnum::fromType<state>().valueToKey(state::IsInitializing));
        emit sendMessage("初始化开始");
    }
}
//运行启动
void RunThread06::startRun()
{
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if ((currentState == state::IsPause))
    {
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState),
                 QMetaEnum::fromType<state>().valueToKey(state::IsRuning));
        emit sendMessage("设备运行");
    }
}
//暂停流程
void RunThread06::startPause()
{
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if ((currentState == state::IsRuning))
    {
        setValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState),
                 QMetaEnum::fromType<state>().valueToKey(state::IsPause));
        emit sendMessage("设备暂停");
    }
}

void RunThread06::startStop()
{

}
//报警复位
void RunThread06::startReset()
{
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if (currentState == state::IsAlarm)
    {
          setValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState),
                   QMetaEnum::fromType<state>().valueToKey(state::IsPause));
          emit sendMessage("设备重启");
    }
}
//报警启动
void RunThread06::startAlarm()
{
    QString currentState_str=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState));
    state currentState = (state)QMetaEnum::fromType<state>().keyToValue(currentState_str.toUtf8());
    if ((currentState != state::IsRuning)&&
        (currentState != state::IsPause))
    {
          setValue(QMetaEnum::fromType<variable>().valueToKey(variable::currentState),
                   QMetaEnum::fromType<state>().valueToKey(state::IsAlarm));
          emit sendMessage("设备报警");
    }
}
/*初始化流程*/
void RunThread06::initAndReset()
 {
     init_0();
     init_1();
 }
/*运行流程*/
void RunThread06::startAndRun()
{
     run_0();
     run_1();

}
/*监控流程*/
void RunThread06::monitor()
{

}

void RunThread06::init_0()
{
    int step=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::int0_step)).toInt();
    switch (step)
    {
        case 1:
            setValue(QMetaEnum::fromType<variable>().valueToKey(variable::int0_step),"100");
            break;
        default:
            break;
    }
}
void RunThread06::init_1()
{
    int step=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::int1_step)).toInt();
    switch (step)
    {
        case 1: //
            setValue(QMetaEnum::fromType<variable>().valueToKey(variable::int1_step),"100");
            break;
         default:
            break;
    }
}
void RunThread06::run_0()
{
    int step=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::run0_step)).toInt();
    switch (step)
    {
        case 1://
            setValue(QMetaEnum::fromType<variable>().valueToKey(variable::run0_step),"100");
            break;
        default:
            break;
   }
}
void RunThread06::run_1()
{
    int step=getValue(QMetaEnum::fromType<variable>().valueToKey(variable::run1_step)).toInt();
    switch (step)
    {
        case 1:
            setValue(QMetaEnum::fromType<variable>().valueToKey(variable::run1_step),"100");
            break;
        default:
            break;
    }
}

bool RunThread06::setValue(QString key, QString value)
{
    m_value.insert(key,value);
    return true;
}

QString RunThread06::getValue(QString key)
{
    return m_value.value(key);
}

void RunThread06::saveConfig()
{
    for(int i=0;m_value.keys().count();i++)
    {

    }
}

void RunThread06::loadConfig()
{

}
